from pathlib import Path
import json,zipfile
root=Path(__file__).resolve().parent
manifest=json.loads((root/'mod.json').read_text())
assert manifest['format']==1
with zipfile.ZipFile(root/'my-mod.pwmod','w',zipfile.ZIP_DEFLATED) as archive:
    archive.write(root/'mod.json','mod.json')
    for relative in sorted(set(manifest.get('resources',{}).values())):
        path=(root/relative).resolve()
        assert path.is_relative_to(root) and path.is_file()
        archive.write(path,relative)
print('Created my-mod.pwmod. Import it from the swipe panel > MODDING.')
