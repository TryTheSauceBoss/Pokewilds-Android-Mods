POKEWILDS GODOT MOD TEMPLATE - FORMAT 1 / MULTI-MOD LIBRARY

Full installation and creation guide:
https://github.com/TryTheSauceBoss/Pokewilds-Android-Mods#readme

INSTALL
Save the game. Swipe inward from the right edge > MODDING > IMPORT MOD.
Select a compatible .pwmod or format-1 ZIP with mod.json at its root.
New IDs install enabled. Different IDs are separate library entries.
Save and fully close/reopen the app to apply all library changes.
A fresh library starts empty. There is no fixed package-count limit.
Each package has ENABLED ON/OFF, LOAD EARLIER, LOAD LATER and REMOVE MOD.
Use UP/DN touch buttons, D-pad or left stick to scroll. A selects; B returns.
ALL MODS OFF disables packages without deleting them. REMOVE MOD asks for
confirmation; keep external copies to reinstall removed packages.

ORDER AND UPDATES
Enabled packages load top to bottom. Later packages win matching resource
paths, individual species properties and whole species shiny palettes.
Unrelated properties combine. Arrays and nested objects replace whole
properties; learnset entries and behavior keys do not merge individually.
CONFLICTS lists direct overlapping keys and the winning later package.
It does not detect every possible gameplay interaction.
Keep a mod's id stable for updates; same-ID imports preserve order and
ON/OFF state. Use different IDs for separate mods. Restart after changes.
Invalid imports leave the library intact. Startup reports missing/invalid
packages and continues loading valid enabled packages.

CREATE
1. Extract this template on a computer with Python 3.
2. Edit mod.json; keep format 1, set a unique id, name, author and version.
3. Put PNG/OGG assets in files/ beside mod.json.
4. Map exact approved resource paths to files/... in resources.
5. Optional species patches use existing canonical species and move IDs.
6. Run python build_mod.py (or py build_mod.py on Windows).
7. Import my-mod.pwmod, restart and test with a backed-up/test save.
The supplied builder packages mod.json and resources-referenced files.
It does not include this README, reference databases or credits automatically.
Distribute credits alongside the package or add them to its archive manually.

REFERENCES AND LIMITS
asset-catalog.json lists supported destinations and dimensions.
species-reference.json describes existing fields and IDs; it is not a patch.
Only approved PNG/OGG replacements, existing species data and two-color
shiny palettes are supported. No scripts, new species IDs, new move logic,
new menus or world-generation code. Match image dimensions/frame order and
preserve alpha. OGG files must actually be Vorbis; original loop settings stay.
Normal artwork and distinct authored shiny artwork are separate. Authored
shiny sprites take priority over palette recoloring. Test every relevant view.
At most 12000 entries; 32 MiB per referenced asset; 256 MiB total referenced
PNG/OGG bytes after decompression. Decoded RAM use can be higher. Paths must
be relative, using forward slashes, with no .., drive letters or duplicates.
The archive must contain mod.json at its root, not inside a wrapper folder.

OPTIONS AND TESTING
Built-in visual/audio options are separate from imported mod slots. They can
select or transform other resources. Test intended option combinations and
use catalog-listed destinations only. Back up saves, test each mod alone,
then test the combination and load order, save/reload, and disable/restart.
Disabling/removing mods does not undo changes already written into saves.
A successful import validates the format, not all gameplay effects.

CREDITS
The scaffold and build script may be reused and modified. Reference data
and artwork remain subject to their respective creators' rights. Include
permissions and credits for artwork/audio that you distribute.
